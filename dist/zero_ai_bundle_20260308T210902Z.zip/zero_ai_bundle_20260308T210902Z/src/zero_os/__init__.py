"""Zero OS package."""
